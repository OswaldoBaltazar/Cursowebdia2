package com.cursoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursowebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursowebApplication.class, args);
	}

}
